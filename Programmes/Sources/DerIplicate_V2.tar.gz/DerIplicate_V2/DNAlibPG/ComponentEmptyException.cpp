/*
 * ComponentEmptyException.cpp
 *
 *  Created on: 3 Jun 2015
 *      Author: pagagne
 */

#include "ComponentEmptyException.h"

namespace PHException {

ComponentEmptyException::ComponentEmptyException(const std::string& p_raison): FastqException(p_raison) {
	// TODO Auto-generated constructor stub

}

} /* namespace PHException */
