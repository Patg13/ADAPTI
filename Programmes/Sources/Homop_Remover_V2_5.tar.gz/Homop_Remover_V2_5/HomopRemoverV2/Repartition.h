/*
 * Repartition.h
 *
 *  Created on: 13 Jul 2015
 *      Author: pagagne
 */

#ifndef REPARTITION_H_
#define REPARTITION_H_

#include <string>
#include <vector>
#include <sstream>
#include <map>



void RepartitionChargeNum(std::vector<int>* p_repartition,int nb_threads, int nb_seqs);

#endif /* REPARTITION_H_ */
